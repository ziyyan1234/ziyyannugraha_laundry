        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Jasa Cuci <a href="https://colorlib.com">Bersih</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../../assets/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../../assets/vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../../assets/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../../assets/vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../../assets/vendors/iCheck/icheck.min.js"></script>
    
  <!-- Vendor JS Files -->
  <script src="../../assets/vendor2/purecounter/purecounter_vanilla.js"></script>
  <script src="../../assets/vendor2/aos/aos.js"></script>
  <script src="../../assets/vendor2/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../../assets/vendor2/glightbox/js/glightbox.min.js"></script>
  <script src="../../assets/vendor2/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../../assets/vendor2/swiper/swiper-bundle.min.js"></script>
  <script src="../../assets/vendor2/waypoints/noframework.waypoints.js"></script>
  <script src="../../assets/vendor2/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../../assets/js/main.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../../assets/build/js/custom.min.js"></script>
  </body>
</html>